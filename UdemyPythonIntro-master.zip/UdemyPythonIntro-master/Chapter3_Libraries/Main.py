from MyModule import list_max
from MyModule import list_min


list1 = [-2, 1, 2, -10, 22, -10]
list_max(list1)
list_min(list1)
list2 = [-20, 123, 112, -10, 22, -120]
list_max(list2)
list_min(list2)
