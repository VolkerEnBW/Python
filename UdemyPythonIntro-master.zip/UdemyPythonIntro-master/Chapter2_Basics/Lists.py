grades = [1, 2, 1]

print(grades)

grades.append(4)

print(grades)

grades.pop()

print(grades)

print("Ben's grade: ", grades[0])
print("Jan's grade: ", grades[1])
print("Peter's grade: ", grades[2])

grades[0] = 3

print(grades)

grades.pop(1)

print(grades)
