"""Exercise 3:
1.)
Write a function that takes a dictionary as an input.
The function then iterates over all values and counts
how many "Students" are in the dictionary.
(See the dict "d" below)
2.)
Write a function that iterates over all key, value pairs
of the dictionary "d" and only print the name of the students.
"""


def exercise1(dct):  # noqa: ARG001
    pass


def exercise2(dct):  # noqa: ARG001
    pass


d = {"Oskar": "Student", "Jan": "Instructor", "Thomas": "Student"}
print(exercise1(d))

exercise2(d)
