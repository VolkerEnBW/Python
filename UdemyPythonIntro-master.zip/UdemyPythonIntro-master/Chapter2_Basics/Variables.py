# 1. var names cannot contain whitespaces
# 2. var names cannot start with a number

my_age = 28  # int
price_for_one_item = 0.5  # float
my_name_is_jan = True  # bool
my_name_is_peter = False  # bool
my_name = "Jan Schaffranek"  # str

print(my_name)
print(my_age)
