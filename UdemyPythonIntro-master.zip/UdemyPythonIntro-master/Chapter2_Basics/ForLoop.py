grades = [1, 2, 1, 4]

for grade in grades:
    print(grade)

print("")

for idx in range(len(grades)):
    print(grades[idx])

print("")

# range(start, stop, step)
for idx in range(0, 10, 2):
    print(idx)
