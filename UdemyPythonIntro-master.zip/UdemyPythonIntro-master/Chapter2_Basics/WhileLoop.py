bank_account = 1000.0

while bank_account > 0.0:
    bank_account = bank_account - 100.0
    print(bank_account)
