var = 10

var += 2
print(var)
var = var + 2
print(var)

var -= 2
print(var)
var = var - 2
print(var)

var *= 2
print(var)
var = var * 2
print(var)

var /= 2
print(var)
var = var / 2
print(var)


var2 = 13
var3 = 3

var4 = var2 // var3
print(var4)
