list_a = []

for _i in range(100):
    list_a.append(5)

print(list_a)

# List comp
list_b = [5 for i in range(100)]

print(list_b)

list_c = [i**2 for i in range(100)]

print(list_c)
