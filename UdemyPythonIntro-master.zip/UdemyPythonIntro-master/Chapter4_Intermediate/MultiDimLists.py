# (3,)
vector = [1, 2, 3]

print(vector)

# (3, 2)
matrix = [[1, 2], [3, 4], [5, 6]]

print(matrix)

print(matrix[0])
print(matrix[1][0])
