list_a = [1, 2, 3]

list_a.append(4)

print(list_a)

# Tuple

tuple_a = (2, True, "hello", 2)

print(tuple_a.count(2))

print(tuple_a.index(2))
