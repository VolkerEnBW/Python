my_value1 = 27
my_value2 = "Jan"


print(f"Age: {my_value1} Name: {my_value2}")

print("Age: ", my_value1, " Name: ", my_value2)

print(f"Age: {my_value1} Name: {my_value2}")

print(f"Age: {my_value1} Name: {my_value2}")
